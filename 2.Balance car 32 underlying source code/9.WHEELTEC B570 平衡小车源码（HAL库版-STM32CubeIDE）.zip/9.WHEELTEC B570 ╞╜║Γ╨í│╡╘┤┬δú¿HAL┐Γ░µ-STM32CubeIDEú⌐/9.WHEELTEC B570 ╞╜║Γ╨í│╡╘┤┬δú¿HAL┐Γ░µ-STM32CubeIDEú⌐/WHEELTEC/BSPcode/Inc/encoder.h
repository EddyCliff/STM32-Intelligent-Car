/*
 * encoder.h
 *
 *  Created on: Jun 14, 2022
 *      Author: lf
 */

#ifndef INC_ENCODER_H_
#define INC_ENCODER_H_
#include "main.h"
int Read_Encoder(u8 TIMX);


#endif /* INC_ENCODER_H_ */
