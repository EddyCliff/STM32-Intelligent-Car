#ifndef __EXTI_H
#define __EXIT_H	 
#include "sys.h"
  /**************************************************************************
���ߣ�ƽ��С��֮��
�ҵ��Ա�С�꣺http://shop114407458.taobao.com/
**************************************************************************/

void EXTIX_Init(void);	//�ⲿ�жϳ�ʼ��		 					    
#endif

void EXTI9_5_IRQHandler(void);

void EXTI15_10_IRQHandler(void);


